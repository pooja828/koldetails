Before running:
1. download Nodejs from Nodejs website
2. open Terminal in VScode to install express library: npm install express
3. install sass library: npm i sass --save-dev

To run code:
1. Ctrl+Shift+5
2. In Terminal 1, enter: npm start
3. In Terminal 2, enter: npm run watch
4. open http link on Browser: http://localhost:3000

For search page: http://localhost:3000/search
For test page: http://localhost:3000/news (will replace with login page soon)
